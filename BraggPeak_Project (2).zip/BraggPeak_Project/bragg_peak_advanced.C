#include "TROOT.h"
#include "TCanvas.h"
#include "TTree.h"
#include "TH2F.h"

void bragg_peak_advanced(){
    
    //gStyle->SetOptStat(0);

    TCanvas *c1 = new TCanvas();
    
    TTree *bragg = new TTree("Bragg Peak","Bragg Peak");
    bragg->ReadFile("BraggPeak150.out","length:edep:step");
    
    TH1F *h100 = new TH1F("h100","Bragg Peak for proton particles",100,0.,5.);
    bragg->Draw("length", "edep/step>100");
    h100->GetXaxis()->SetTitle("Range (cm)");
    h100->GetYaxis()->SetTitle("dE/dx (MeV/cm)");
    c1->SetLogz();
    //c1->SaveAs("BraggPeak50.png");
  
}
