
#include "PrimaryGeneratorAction.hh"
#include "DetectorConstruction.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "globals.hh"

// para utilizar o rand e o cos
#include "Randomize.hh"
#include <math.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>

using namespace CLHEP;
using namespace std;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

  //Distribuicao Gaussiana de energia
  float gaussiana(float m, float s){
    //criar dois numeros aleatorios que seguem uma dist. normal
    float u1 = rand()*1.0/RAND_MAX;
    float u2 = rand()*1.0/RAND_MAX;
    float Z = sqrt(-2.0*log(u1))*cos(2*pi*u2);
    float E = m + Z*s;
    return E;
  }

PrimaryGeneratorAction::PrimaryGeneratorAction(
                                               DetectorConstruction* myDC)
:myDetector(myDC)
{
  G4int n_particle = 1;
  particleGun = new G4ParticleGun(n_particle);

  // default particle
  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4ParticleDefinition* particle = particleTable->FindParticle("proton");
  

  
  
  particleGun->SetParticleDefinition(particle);
  particleGun->SetParticleMomentumDirection(G4ThreeVector(1.,0.,0.));
  float g = gaussiana(1,0.02);
  particleGun->SetParticleEnergy(g*150*MeV); //energia que segue uma distribuicao gaussiana
  particleGun->SetParticlePosition(G4ThreeVector(-10.*cm,0.*cm,0.*cm));
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete particleGun;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{ 
  
  particleGun->GeneratePrimaryVertex(anEvent);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

