#include "TROOT.h"
#include "TTree.h"
#include "TH2F.h"

void bragg_peak(){
    TTree *bragg = new TTree("Bragg Peak","Bragg Peak");
    bragg->ReadFile("BraggPeak50.out","length:edep:step");
    
    bragg->Draw("edep/step:length");
    
}
